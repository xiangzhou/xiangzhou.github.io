
wtsc <- function(wtLD.score, hetLD.score, N, M, intercept.one, h2.iter){
  #wtLD.score:            ld score
  #hetLD.score:           ld score
  #N:                     Sample size of GWAS
  #M:                     Number of SNPs
  #intercept.one:         Intercept
  #h2.iter:               Heritability or Vg
  h2.iter <- max(h2.iter, 0)
  h2.iter <- min(h2.iter, 1)
  het.wt <- 1 / (2 * (intercept.one +  h2.iter * N * hetLD.score/M) ^ 2)
  nind.wt <- 1 / wtLD.score
  wt <- het.wt * nind.wt
  wt <- (sqrt(wt) / sum(sqrt(wt))) ^ 2
  return(wt)
}
#
JK <- function(wy, wx, n.block = 200){
  theta.all.est <- coef(lm(wy~wx - 1))
  snp_M <- length(wy)
  wx_p <- ncol(wx)
  num.snp <- length(wy)
  p.x <- dim(wx)[2]
  block_seg <- round(seq(1, snp_M, length.out = n.block + 1), 0)
  theta_del_mat <- matrix(NA, n.block, wx_p)
  for(del_block in 1:n.block){
    del_index <- block_seg[del_block] : block_seg[del_block +1]
    theta_del_mat[del_block, ] <- coef(lm(wy[-del_index] ~ wx[-del_index, ] - 1))
  }
  theta_mat <- t(theta.all.est * n.block - t((n.block - 1) * theta_del_mat))
  theta_est <- apply(theta_mat, 2, mean)
  theta_cov <- cov(theta_mat) / n.block
  theta_se <- sqrt(diag(theta_cov))
  wald_stat <- as.vector(t(theta_est[2:(wx_p - 1)]) %*% solve(theta_cov[2:(wx_p - 1), 2:(wx_p - 1)]) %*% theta_est[2:(wx_p - 1)])
  theta_name <- colnames(wx)
  names(theta_est) <- theta_name
  names(theta_se) <- theta_name
  colnames(theta_cov) <- row.names(theta_cov) <- theta_name
  return(list(theta.est =  theta_est, theta.se =  theta_se,  theta.cov =  theta_cov, TRD.Wald = wald_stat))
}
#sqrt.wy = sqrt_wty; wx = wtx; LD.dir = LD.dir; N = N; sma = sma; theta.est = theta_est
SW <- function(sqrt.wy, wx, LD.dir, N, sma, theta.est){
  sma_name <- colnames(sma)
  sma_M <- length(sma_name)
  snp_M <- nrow(sma)
  beta_nvg <- as.vector(sma %*% theta.est[1:sma_M] * N / snp_M)
  Dbeta_nvg <- sparseMatrix(1:snp_M, 1:snp_M, x = beta_nvg)
  Dz <- sparseMatrix(1:snp_M, 1:snp_M, x = sqrt.wy)
  mid_term <- matrix(0, sma_M + 1, sma_M + 1)
  refLD_N <- length(list.files(LD.dir))
  snp_index <- 0
  for(i in 1:refLD_N){
    load(paste(LD.dir, "ldsmat_", i, ".RData", sep = ""))
    snp_ld_i_index <- snp_index + nrow(R.mat)
    subwx <- wx[(snp_index + 1):snp_ld_i_index , ]
    subDbeta_nvg <- Dbeta_nvg[(snp_index + 1):snp_ld_i_index, (snp_index + 1):snp_ld_i_index]
    subDz <- Dz[(snp_index + 1):snp_ld_i_index, (snp_index + 1):snp_ld_i_index]
    mid_term <- mid_term + 2 * t(subwx) %*% subDz %*% (R.mat %*% subDbeta_nvg %*% R.mat + R.mat * (theta.est[sma_M + 1] - theta.est[1])) %*% subDz %*% subwx
    snp_index <- snp_index + snp_ld_i_index
    cat("######        Mid-term for block  # ", i, " # has been finished!         ######", fill = T)
    rm(i, R.mat)
  }
  theta_name <- c("Vg", sma_name[-1], "Vp")
  side_term <- solve(crossprod(wx))
  theta_cov <- side_term %*% mid_term %*% side_term
  theta_cov <- as.matrix(theta_cov)
  theta_se <- sqrt(diag(theta_cov))
  wald_stat <- as.vector(t(theta.est[2:sma_M]) %*% solve(theta_cov[2:sma_M , 2:sma_M]) %*% theta.est[2:sma_M])
  names(theta.est) <- theta_name
  names(theta_se) <- theta_name
  colnames(theta_cov) <- row.names(theta_cov) <- theta_name
  return(list(theta.est =  theta.est, theta.se =  theta_se,  theta.cov =  theta_cov, TRD.Wald = wald_stat))
}
#
#sma = sma; LD.dir = LD.dir; N = N
PSI <- function(sma, LD.dir, N){
  #sma:          Multiple annotation (SNP  CHR  ann1  ann2 ann3 ...)
  #LD.dir:       Directory where saves the reference LD matrix, which can be separated into different chromosome
  #N:            Sample size of GWAS
  sma_name <- colnames(sma)
  sma_M <- length(sma_name)
  snp_M <- nrow(sma)
  ldsc_mat <- matrix(NA, snp_M, sma_M)
  colnames(ldsc_mat) <- sma_name
  refLD_N <- length(list.files(LD.dir))
  snp_index <- 0
  for (i in 1:refLD_N){
    load(paste(LD.dir, "ldsmat_", i, ".RData", sep = ""))
    Omega.mat <- R.mat ^ 2
    snp_ld_i_index <- snp_index + nrow(Omega.mat)
    sma_i <- sma[(snp_index + 1):snp_ld_i_index, ]
    ldsc_mat[(snp_index + 1):snp_ld_i_index, ] <- as.matrix(Omega.mat %*% sma_i)
    cat("######         LD score for block  # ", i, " # has been finished!         ######", fill = T)
    snp_index <- snp_index + snp_ld_i_index
    rm(i, R.mat, Omega.mat, sma_i)
  }
  if(snp_index != snp_M) {
    stop("Reference LD matrix and multiple annotations have different number of SNPs")
  }
  lm.x <- cbind(ldsc_mat * N / snp_M, 1)
  base.ld <- ldsc_mat[, 1]
  base.ld[base.ld < 1] < 1
  cat.ld <- rowSums(ldsc_mat)
  cat.ld[cat.ld < 1] <- 1
  return(list(x = lm.x, base.ld = base.ld, cat.ld = cat.ld))
}
#gss = sumstat_dat; sma = ann; LD.dir = dir_linux; ma.scale = T
SMART <- function(gss, sma, LD.dir, ma.scale = T, method = "Sandwich"){
  #gss:          GWAS summary statistics (SNP  CHR  N  Z)
  #sma:          Multiple annotation (SNP  CHR  ann1  ann2 ann3 ...)
  #LD.dir:       Directory where saves the reference LD matrix, which can be separated into different chromosome
  #ma.scale      Whether the multipe annotations should be standardized.
  #method:       Method to compute the estimate variance
  if(nrow(gss) != nrow(sma)) {
    stop("GWAS summary statistics and multiple annotations have different number of SNPs")
  }
  if(!all(gss$SNP == sma$SNP)) {
    stop("GWAS summary statistics and multiple annotations have different SNP order")
  }
  M <- nrow(gss)
  N <- min(gss$N)
  #
  sma <- sma[, -c(1:2)]
  if(ma.scale) {
    sma <- scale(sma)
  }
  sma <- cbind(1, sma)
  colnames(sma)[1] <- "Intercept"
  sma_name <- colnames(sma)
  #
  psi_est <- PSI(sma = sma, LD.dir = LD.dir, N = N)
  X <- psi_est$x
  wt_refLD <- psi_est$base.ld
  het_refLD <- psi_est$cat.ld
  X_p <- ncol(X)
  y <- (gss$Z) ^ 2
  intercept_start <- 1
  h2_start <- (mean(y) - 1) * M /(mean(het_refLD) * N)
  update.IRWLS <- function(it.num, it.limit){
    for(it_index in 1:it.num){
      wt_score <- wtsc(wtLD.score = wt_refLD, hetLD.score = het_refLD, N = N, M = M, intercept.one = intercept_start, h2.iter = h2_start)
      wt_score_sqrt <- sqrt(wt_score)
      wtx <- X * wt_score_sqrt
      wty <- y * wt_score_sqrt
      theta_end <- unname(coef(lm(wty~wtx-1)))
      if(it_index > 1 & abs(theta_end[1] - h2_start) <= it.limit) {
        cat("Iteration   " ,it_index, "  Converged at  ", it.limit, fill = T)
        break
      } else {
        theta_start <- theta_end
        intercept_start <- theta_start[X_p]
        h2_start <- theta_start[1]
      }
    }
    return(list(IRWLS.est = theta_end, IRWLS.wt = wt_score))
  }
  update_est <- update.IRWLS(it.num = 3, it.limit = 0.001)
  if(method == "Jackknife") {
    theta_est <- update_est$IRWLS.est
    wt_score <- update_est$IRWLS.wt
    wt_score_sqrt <- sqrt(wt_score)
    wtx <- X * wt_score_sqrt
    colnames(wtx) <- c("Vg", sma_name[-1], "Vp")
    wty <- y * wt_score_sqrt
    jknife <- JK(wy = wty, wx = wtx, n.block = 200)
    return(jknife)
  }
  if(method == "Sandwich") {
    theta_est <- update_est$IRWLS.est
    wt_score <- update_est$IRWLS.wt
    wt_score_sqrt <- sqrt(wt_score)
    wtx <- X * wt_score_sqrt
    sqrt_wty <- sqrt(y) * wt_score_sqrt
    sandwich <- SW(sqrt.wy = sqrt_wty, wx = wtx, LD.dir = LD.dir, N = N, sma = sma, theta.est = theta_est)
    return(sandwich)
  }
}

#
#
Block.ld <- function(geno.x, geno.map, refld.bed){
  #geno.file: n x m scaled genotype matrix
  #ld.mode: banded or blocked sparse matrix
  #refld.be: referred ld block pattern, should contain: chr start stop
  X <- geno.x
  num_snp <- ncol(X)
  SNP_pos <- as.numeric(geno.map$BP)
  R.mat <- matrix(0, 1, 1)
  for(i in 1:nrow(refld.bed)) {
    #i <- 10
    start_index <- refld.bed[i, 2]
    stop_index <- refld.bed[i, 3]
    sub_index <- which(SNP_pos >= start_index & SNP_pos < stop_index)
    if(length(sub_index) != 0){
      x_sub <- X[, sub_index]
      ld_rmat_sub <- cor(x_sub)
      R.mat <- bdiag(R.mat, ld_rmat_sub)
    }
  }
  R.mat <- R.mat[-1, -1]
  Omega.mat <- R.mat ^ 2
  sum_r2 <- apply(Omega.mat, 2, sum)
  ldscore_dat <- data.frame(geno.map, l2 = sum_r2)
  return(list(Rmat = R.mat, Omat = Omega.mat, ldsc = ldscore_dat))
}
Band.ld <- function(geno.x, geno.map, ld.mode, win.size){
  #geno.file: n x m scaled genotype matrix
  #ld.mode: banded or blocked sparse matrix
  #refld.be: referred ld block pattern, should contain: chr start stop
  X <- geno.x
  num_snp <- ncol(X)
  num_id <- nrow(X)
  LD.func <- function(Gx){
    ld_r <- apply(Gx, 2, function(x) cor(x, Gx[, 1]))
    return(ld_r)
  }
  if(ld.mode == "gcm_band"){
    cm_vec <- as.numeric(geno.map$cM)
  }
  if(ld.mode == "Mb_band"){
    cm_vec <- as.numeric(geno.map$BP) / 1000000
  }
  cm_mat <- cbind(cm_vec, 1:num_snp)
  cell_index <- apply(cm_mat, 1, function(x){
    all_snp <-  which(x[1] <=  cm_vec & cm_vec < (x[1] + win.size))
    big_snp <- all_snp[all_snp >= x[2]]
    return(big_snp)
  })
  col_index <- unlist(cell_index)
  row_mat_temp <- cbind(1:num_snp, sapply(cell_index, length))
  row_index <- unlist(apply(row_mat_temp, 1, function(x) rep(x[1], x[2])))
  ld_r_list <- lapply(cell_index, function(x) {
    x_select <- as.numeric(x)
    temp <- matrix(X[, x_select], nrow = num_id)
    ld_r_temp <- LD.func(Gx = temp)
    return(ld_r_temp)
    cat(ld.temp, fill = T)
  })
  ld_r <- unlist(ld_r_list)
  ld_r2 <- ld_r ^ 2
  sum_r2 <- sapply(ld_r_list, function (x) sum(x ^ 2))
  ldscore_dat <- data.frame(geno.map, l2 = sum_r2)
  R.mat <- sparseMatrix(row_index, col_index, x = ld_r, symmetric = T)
  Omega.mat <- sparseMatrix(row_index, col_index, x = ld_r2, symmetric = T)
  return(list(Rmat = R.mat, Omat = Omega.mat, ldsc = ldscore_dat))
}
LDSM <- function(geno.x, geno.map, ld.mode, win.size = NULL, refld.bed = NULL){
  #geno.file: n x m scaled genotype matrix
  #geno.map: snp map, contain: CHR, SNP,cM,BP
  #ld.mode: banded or blocked sparse matrix
  #refld.be: referred ld block pattern, should contain: chr, start, stop
  X <- geno.x
  if(ld.mode == "gcm_band"){
    return(Band.ld(geno.x = X, geno.map = geno.map, ld.mode = "gcm_band", win.size = win.size))
  }
  if(ld.mode == "Mb_band"){
    return(Band.ld(geno.x = X, geno.map = geno.map, ld.mode = "Mb_base", win.size = win.size))
  }
  if(ld.mode == "ref_block"){
    return(Block.ld(geno.x = X, geno.map = geno.map, refld.bed = refld.bed))
  }
}


EMmix <- function(Zsq, df.zsq, beta.mean = 0.1, iter.max = 100, iter.limit = 0.001, NCP.diff.limit = NULL) {
  num_Zsq <- length(Zsq)
  beta_a <- num_Zsq * 10
  beta_b <- (1 - beta.mean) * beta_a / beta.mean
  ##############################     optim funciton    ##############################
  optim2 <- function(par) {
    p.it <- par[1]
    ncp1.it <- par[2]
    ncpdiff.it <- par[3]
    if(ncpdiff.it < NCP.diff.limit) {
      ncpdiff.it <- NCP.diff.limit
    }
    ncp2.it <- ncp1.it - ncpdiff.it
    if(ncp2.it < 0) {
      ncp2.it <- 0
    }
    Q_max <- (sum(latent_pi) + beta_a -1) * log(p.it) + (sum(1- latent_pi) + beta_b - 1) * log(1-p.it) + sum(latent_pi * log(dchisq(Zsq, df = df.zsq, ncp = ncp1.it))) + sum((1 - latent_pi) * log(dchisq(Zsq, df = df.zsq, ncp = ncp2.it)))
    return(-Q_max)
  }
  ####################################################################################
  p <- rbeta(1, beta_a, beta_b)  # initial p value
  ncp1 <- summary(Zsq)[5]   # initial ncp1
  ncp2 <- summary(Zsq)[2]   # initial ncp2
  ncpdiff <- ncp1 - ncp2   # initial ncpdiff
  par_start <- c(p, ncp1, ncpdiff)
  max_loglik <- rep(NA, iter.max)
  post1_index <- NULL # maybe the greatest
  post0_index <- NULL # maybe the smallest
  latent_pi <- p * dchisq(Zsq, df = df.zsq, ncp = ncp1) / (p * dchisq(Zsq, df = df.zsq, ncp = ncp1) + (1 - p) * dchisq(Zsq, df = df.zsq, ncp = ncp2))
  if(any(is.na(latent_pi))) {
    del_index <- which(is.na(latent_pi))
    post1_index <- c(post1_index, which(Zsq[del_index] > mean(Zsq))) # maybe the greatest
    post0_index <- c(post0_index, which(Zsq[del_index] < mean(Zsq))) # maybe the smallest
    Zsq <- Zsq[-del_index]
    ncp1 <- max(c(median(Zsq), mean(Zsq)))   # initial ncp1
    ncp2 <- min(c(median(Zsq), mean(Zsq)))   # initial ncp2
    ncpdiff <- ncp1 - ncp2   # initial ncpdiff
    par_start <- c(p, ncp1, ncpdiff)
    cat("    ######   ATTENTION: some extramely samll or great values   ######    ", fill = T)
  }
  if(is.null(NCP.diff.limit)){
    NCP.diff.limit <- summary(Zsq)[5] - summary(Zsq)[2]
  }
  for(iter_i in 1:iter.max){
    latent_pi <- p * dchisq(Zsq, df = df.zsq, ncp = ncp1) / (p * dchisq(Zsq, df = df.zsq, ncp = ncp1) + (1 - p) * dchisq(Zsq, df = df.zsq, ncp = ncp2))
    optim_Q <-  optim(par = par_start, optim2)
    par.opt <- optim_Q$par
    p <- par.opt[1]
    ncp1 <- par.opt[2]
    ncpdiff <- par.opt[3]
    ncp2 <- ncp1 - ncpdiff
	if(ncp2 < 0){
      ncp2 <- 0
      ncp1 <- 0.1
      ncpdiff <- ncp1
    }
    par_start <- c(p, ncp1, ncpdiff)
    par_end <- c(p, ncp1, ncp2)
    max_loglik[iter_i] <- -optim_Q$value
    if(iter_i > 1 && abs(max_loglik[iter_i] - max_loglik[iter_i - 1]) < iter.limit){
      cat("    ######    Congratulations, the likelihood has been converged !!   ######    ", fill = T)
      break
    }
  }
  pip <- p * dchisq(Zsq, df = df.zsq, ncp = ncp1) / (p * dchisq(Zsq, df = df.zsq, ncp = ncp1) + (1 - p) * dchisq(Zsq, df = df.zsq, ncp = ncp2))
  ## PIP
  if(length(pip) == num_Zsq) {
    pip.all <- pip
  }
  if(length(pip) < num_Zsq & !is.null(post1_index) & is.null(post0_index)){
    pip.all <- rep(1, num_Zsq)
    pip.all[-post1_index] <- pip
  }
  if(length(pip) < num_Zsq & is.null(post1_index) & !is.null(post0_index)){
    pip.all <- rep(1, num_Zsq)
    pip.all[-post0_index] <- pip
  }
  if(length(pip) < num_Zsq & !is.null(post1_index) & !is.null(post0_index)){
    pip.all <- rep(NA, num_Zsq)
    pip.all[-c(post0_index, post1_index)] <- pip
    pip.all[post1_index] <- 1
    pip.all[post0_index] <- 0
  }
  names(par_end) <- c("p", "ncp1", "ncp2")
  max_loglik <- as.numeric(na.omit(max_loglik))
  return(list(Par.est = par_end, PP = pip.all, Loglik = max_loglik, Iter.num = iter_i))
}
